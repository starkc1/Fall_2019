Steps To Run Program:

1.) mem_in.txt needs to be in same folder as exe
2.) run exe by running double clicking the Stark_main.exe or gcc Stark_main.c then Stark_main
3.) mem_out.xt needs to be in the same folder as exe